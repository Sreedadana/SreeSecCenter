let config = {
    'authHistory': undefined,
    'authSession': undefined,
    'authHistoryView': undefined,
    'authSessionView': undefined,
    'participants': undefined,
    'participantsView': undefined,
    'participantsForm': undefined,
    'participantsFormView': undefined,
}

function authHistoryAPI() {
    fetch('../mock-data/Config.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let dataSource = data.dataSources;
            let view = data.views;
            config.authHistory = { ...dataSource.filter((item) => item.id == 'authHistory')[0]
            };
            config.authHistoryView = { ...view.filter((item) => item.id == 'authHistory')[0]
            };
            let authHContent = document.querySelector("#authHistory-content");
            let displayList = getTableContent(config.authHistory.mockDataSet,config.authHistoryView.columns,'authHistory');
            let displayHeader = getTableHeader(config.authHistoryView.columns,'authHistory');

            let table = document.createElement('table');
            table.setAttribute('class','table table-bordered');
            let tHead = document.createElement('thead');
            tHead.append(displayHeader);
            table.append(tHead);
            table.append(displayList);
        
            if (authHContent) {
                authHContent.innerHTML = '<span style="display:none;"></span>';
                authHContent.append(table);
            }

        });
}

function authSessionAPI() {
    fetch('../mock-data/Config.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let dataSource = data.dataSources;
            let view = data.views;
            config.authSession = { ...dataSource.filter((item) => item.id == 'authSession')[0]
            };
            config.authSessionView = { ...view.filter((item) => item.id == 'authSession')[0]
            };
            let authSContent = document.querySelector("#authSession-content");
            let displayList = getTableContent(config.authSession.mockDataSet,config.authSessionView.columns,'authSession');
            let displayHeader = getTableHeader(config.authSessionView.columns,'authSession');

            let table = document.createElement('table');
            table.setAttribute('class','table table-bordered');
            let tHead = document.createElement('thead');
            tHead.append(displayHeader);
            table.append(tHead);
            table.append(displayList);
        
            if (authSContent) {
                authSContent.innerHTML = '<span style="display:none;"></span>';
                authSContent.append(table);
            }
        });
}

function participantsAPI() {
    fetch('../mock-data/Participants.json')
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        let dataSource = data.dataSources;
        let view = data.views;
        config.participants = { ...dataSource.filter((item) => item.id == 'participants')[0]
        };
        config.participantsView = { ...view.filter((item) => item.id == 'participants')[0]
        };

        let participantsContent = document.querySelector("#participants-content");
        let displayHeader = getTableHeader(config.participantsView.columns,'participants');

        let displayList = getTableContent(config.participants.mockDataSet,config.participantsView.columns,'participants');

        let table = document.createElement('table');
        table.setAttribute('class','table table-bordered');

        let tHead = document.createElement('thead');
        
        tHead.append(displayHeader);
        table.append(tHead);
        table.append(displayList);

        let createBtn = document.createElement('button');
        createBtn.setAttribute('type','button');
        createBtn.innerHTML = 'CREATE A RECORD';
        createBtn.addEventListener('click',function(e) {
            var newObject = getEmptyObject();
            config.participants.mockDataSet.push(newObject);
            appendEmptyRow(table.querySelectorAll('tbody')[0],config.participantsView.columns);
        });

        let submitBtn = document.createElement('button');
        submitBtn.setAttribute('type','button');
        submitBtn.innerHTML = 'SUBMIT';
        submitBtn.addEventListener('click',function(e) {
            console.log('Submitted new record');
        });
        
        
        if (participantsContent) {
            participantsContent.innerHTML = '';
            participantsContent.append(table);
            participantsContent.append(createBtn);
            participantsContent.append(submitBtn);
        }

    });
}

function appendEmptyRow(container,columns) {
    let row = document.createElement('tr');
    getRowFormFields(config.participants.mockDataSet[config.participants.mockDataSet.length-1],columns,row,config.participants.mockDataSet.length-1);
    container.append(row);
}

function getEmptyObject() {
    var emptyObj = {
        "issuerParty": "",
        "taxId": "",
        "editable": false,
        "employment": {
          "employeeNumber": "",
          "hireDate": "",
          "terminationDate": ""
        },
        "fullName": {
          "given": "",
          "middle": "",
          "family": ""
        },
        "addresses": [{
            "context": "home",
            "lineOne": "",
            "lineTwo": "",
            "city": "",
            "countrySubdivision": "",
            "postalCode": "",
            "countryCode": ""
          },
          {
            "context": "work",
            "lineOne": "",
            "lineTwo": "",
            "city": "",
            "countrySubdivision": "",
            "postalCode": "",
            "countryCode": ""
          }
        ],
        "phoneNumbers": [{
            "context": "home",
            "digits": ""
          },
          {
            "context": "work",
            "digits": ""
          }
        ],
        "emailAddresses": [{
          "context": "home",
          "address": ""
        }],
        "id": "",
        "promoted": false,
        "birthDate": "",
        "uuid": ""
      }
    return emptyObj;
}

function getTableHeader(columns,type) {
    let tHeadRow = document.createElement('tr');
    if(type === 'participants') {
        let tableActionHead = document.createElement('th');
        tableActionHead.innerHTML = '';
        tHeadRow.append(tableActionHead);
    }
    columns.map((column,columnIndex) => {
        let tableHead = document.createElement('th')
        tableHead.innerHTML = column.label;
        tHeadRow.append(tableHead);
    });
    return tHeadRow;
}

function getTableContent(dataset,columns,type) {
    let tBody = document.createElement('tbody');

    dataset.map((record, recordIndex) => {
        let displayRows = getRowFields(record,recordIndex,columns,type);
        tBody.append(displayRows);
    });
    return tBody;
}

function getRowFields(record,index,columns,type) {
    let tableRow = document.createElement('tr');
    if(type === 'participants') {
        let actionCell = document.createElement('td');

        let updateButton = document.createElement('button');
        updateButton.setAttribute('type','button');
        updateButton.innerHTML = 'UPDATE';
        updateButton.addEventListener('click',function(e) {
            let updatedRow = getRowFormFields(config.participants.mockDataSet[index],columns,this.closest('tr'),index);
        });

        let deleteButton = document.createElement('button');
        deleteButton.setAttribute('type','button');
        deleteButton.addEventListener('click',function(e) {
            config.participants.mockDataSet.splice(index, 1);
            this.closest('tr').remove();
        });
        deleteButton.innerHTML = 'DELETE';

        actionCell.append(updateButton);
        actionCell.append(deleteButton);
        tableRow.append(actionCell);
    }
    columns.map((column, columnIndex) => {
        let tableCell = document.createElement('td');
        const fieldData = record[column.id];
        if(type === 'participants') {
            tableCell.innerHTML = getDisplayer(fieldData,column);
        } else {
            tableCell.innerHTML = fieldData;
        }
        tableRow.append(tableCell);
    });
    return tableRow;
}

function getDisplayer(fieldData,column) {
    const dataType = typeof fieldData;
    switch (dataType) {
        case 'boolean':
            return fieldData;
        case 'object':
            let displayer = column.displayer.pattern.split('\n').map(d => d.slice(1, -1));
            let seperator = column.displayer.separator + " ";
            if (Array.isArray(fieldData)) {
                let homeChecked = column.homeChecked;
                let obj;
                if (homeChecked) {
                    obj = fieldData.filter(a => a.context == 'home')[0];
                    if (!obj) {
                        obj = fieldData.filter(a => a.context == 'work')[0];
                    }
                } else {
                    obj = fieldData.filter(a => a.context == 'work')[0];
                    if (!obj) {
                        obj = fieldData.filter(a => a.context == 'home')[0];
                    }
                }
                displayer = displayer.map(i => obj[i]).filter(j => j).join(seperator);
            } else {
                displayer = displayer.map(i => fieldData[i]).filter(j => j).join(seperator);
            }
            return displayer;
        default: 
            return fieldData;
    }
}

function getFormDisplayer(fieldData,column,currentRow) {
    const dataType = typeof fieldData;
    let tableCell = document.createElement('td');
    let rootDiv = document.createElement('div');
    switch (dataType) {
        case 'boolean':
            updateForm(rootDiv,'',column.id,column.label,fieldData,dataType);
            tableCell.append(rootDiv);
            currentRow.append(tableCell);
            return fieldData;
        case 'object':
            let displayer = column.displayer.pattern.split('\n').map(d => d.slice(1, -1));
            let seperator = column.displayer.separator + " ";
            if (Array.isArray(fieldData)) {
                let homeChecked = column.homeChecked;
                let obj;
                if (homeChecked) {
                    obj = fieldData.filter(a => a.context == 'home')[0];
                    if (!obj) {
                        obj = fieldData.filter(a => a.context == 'work')[0];
                    }
                } else {
                    obj = fieldData.filter(a => a.context == 'work')[0];
                    if (!obj) {
                        obj = fieldData.filter(a => a.context == 'home')[0];
                    }
                }
                rootDiv.setAttribute('class','form-group row');
                Object.keys(displayer).map(function(i) {
                    updateForm(rootDiv,displayer[i],column.id,column.label,obj[displayer[i]],dataType);
                });

                tableCell.append(rootDiv);
                currentRow.append(tableCell);
            } else {
                rootDiv.setAttribute('class','form-group row');
                Object.keys(displayer).map(function(i) {
                    updateForm(rootDiv,displayer[i],column.id,column.label,fieldData[displayer[i]],dataType);
                });

                tableCell.append(rootDiv);
                currentRow.append(tableCell);
            }
            return displayer;
        default: 
            updateForm(rootDiv,'',column.id,column.label,fieldData,dataType);
            tableCell.append(rootDiv);
            currentRow.append(tableCell);
            return fieldData;
    }
}

function submitUpdatedData(fieldData,column,currentRow,index) {
    const dataType = typeof fieldData;
    let currentElement;
    switch (dataType) {
        case 'boolean':
            currentElement = currentRow.querySelectorAll('#' + column.id)[0];
            config.participants.mockDataSet[index][column.id] = currentElement.checked;
            return fieldData;
        case 'object':
            let displayer = column.displayer.pattern.split('\n').map(d => d.slice(1, -1));
            let seperator = column.displayer.separator + " ";
            if (Array.isArray(fieldData)) {
                let homeChecked = column.homeChecked;
                Object.keys(displayer).map(function(i) {
                    currentElement = currentRow.querySelectorAll('#' + column.id + '-' + displayer[i])[0];
                    if (homeChecked) {
                        config.participants.mockDataSet[index][column.id].filter(function(a) {
                            if(a.context === 'home') {
                                a[displayer[i]] = currentElement.value;
                            }
                        });
                    } else {
                        config.participants.mockDataSet[index][column.id].filter(function(a) {
                            if(a.context === 'work') {
                                a[displayer[i]] = currentElement.value;
                            }
                        });
                    }
                });
            } else {
                Object.keys(displayer).map(function(i) {
                    currentElement = currentRow.querySelectorAll('#' + column.id + '-' + displayer[i])[0];
                    config.participants.mockDataSet[index][column.id][displayer[i]] = currentElement.value;
                });
            }
            return fieldData;
        default: 
            currentElement = currentRow.querySelectorAll('#' + column.id)[0];
            config.participants.mockDataSet[index][column.id] = currentElement.value;
            return fieldData;
    }
}

function updateForm(rootDiv,subId,columnId,columnLabel,value,type) {
    let labelForCell = document.createElement('label');
    labelForCell.setAttribute('class','col-sm-2 col-form-label');
    if(type === 'object') {
        labelForCell.setAttribute('for',columnLabel + '-' + subId);
        labelForCell.innerHTML = columnLabel + '-' + subId;
    } else {
        labelForCell.setAttribute('for',columnLabel);
        labelForCell.innerHTML = columnLabel;
    }
    let inputDiv = document.createElement('div');
    inputDiv.setAttribute('class','col-sm-10');
    
    let inputElement = document.createElement('input');
    inputElement.setAttribute('setAttribute','form-control');
    if(type === 'boolean') {
        inputElement.setAttribute('id',columnId);
        inputElement.setAttribute('name',columnId);
        inputElement.setAttribute('type','checkbox');
        if(value == 'true') {
            inputElement.setAttribute('checked',true);
        } else {
            inputElement.removeAttribute('checked');
        }
    } else {
        inputElement.setAttribute('type','text');
        if(type === 'object') {
            inputElement.setAttribute('id',columnId + '-' + subId);
            inputElement.setAttribute('name',columnId + '-' + subId);
            inputElement.setAttribute('placeholder',columnLabel + '-' + subId);
        } else {
            inputElement.setAttribute('id',columnId);
            inputElement.setAttribute('name',columnId);
            inputElement.setAttribute('placeholder',columnLabel);
        }
        inputElement.setAttribute('value',value);
    }
    inputDiv.append(inputElement);
    rootDiv.append(labelForCell);
    rootDiv.append(inputDiv);
}

function getRowFormFields(record,columns,currentRow,index) {
    currentRow.innerHTML = '';
    
    let actionCell = document.createElement('td');
    let updateRecordButton = document.createElement('button');
    updateRecordButton.setAttribute('type','button');
    updateRecordButton.setAttribute('class','btn btn-primary');
    updateRecordButton.setAttribute('id','updateRecordBtn');
    updateRecordButton.innerHTML = 'Update Record';
    updateRecordButton.addEventListener('click',function(e) {
        columns.map((column, columnIndex) => {
            submitUpdatedData(record[column.id],column,this.closest('tr'),index);
        });
        let updatedData = getRowFields(config.participants.mockDataSet[index],index,columns,'participants');
        this.closest('tr').innerHTML = updatedData.innerHTML;
    });
    actionCell.append(updateRecordButton);
    currentRow.append(actionCell);
    columns.map((column, columnIndex) => {
        getFormDisplayer(record[column.id],column,currentRow);
    });
    return currentRow;
}
