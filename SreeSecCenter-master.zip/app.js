const express = require('express');

const app = express();
const path = require('path');
const engine = require('consolidate');
app.use(express.static(path.join(__dirname, 'SecCenter')));

app.set('views', `${__dirname}/SecCenter`);
app.engine('html', engine.mustache);
app.set('view engine', 'html');

app.get('/', (req, res) => {
  res.render(`${__dirname}/SecCenter/index`);
});
app.listen('3330', function() {
  console.log('Server Listening');
});
