'use strict';

const watchify = require('watchify');
const browserify = require('browserify');
const gulp = require('gulp');
const source = require('vinyl-source-stream');
const buffer = require('vinyl-buffer');
const log = require('gulplog');
const sourcemaps = require('gulp-sourcemaps');
const assign = require('lodash.assign');
const babel = require('gulp-babel');
const babelify = require('babelify');
const eslint = require('gulp-eslint');
const uglify = require('gulp-uglify');
const config = require('./config/frameworkConfig.js');

let entryPointArray = []; //This array variable declared to push the index filenames of each modules based on the config variable.
let filename = ''; //This variable is declared to store the file name which needs to be push into entryPointArray.

filename = './src/utils/exportedFunc.js';
entryPointArray.push(filename);
filename = './src/modules/default/index.js';
entryPointArray.push(filename);

//Conditions to validate the config boolean values of each functionalities.
if(config.config.all_functionality && config.config.all_functionality.valid) {
  for(var a in config.config) {
    if(a === 'all_functionality') {}
    else{
      entryPointArray.push(config.config[a].fileName);
    }
  }
}
if(config.config.custom_flow && config.config.custom_flow.valid) {
  entryPointArray.push(config.config.custom_flow.fileName);
}

console.log(entryPointArray);
// add custom browserify options here
var customOpts = {
  entries: entryPointArray,
  debug: true,
  standalone: 'myApp',
  transform: [
    [ 'babelify', { presets: ['es2015', 'stage-2'] } ]
  ]
};
var opts = assign(watchify.args, customOpts);
var b = watchify(browserify(opts)); 
var a = browserify(opts);

gulp.task('watch', autoBundle); // so you can run `gulp js` to build the file
gulp.task('build', bundle); // so you can run `gulp js` to build the file
gulp.task('test', ['lint']); // so you can run `gulp js` to build the file

b.on('update', autoBundle); // on any dep update, runs the bundler
b.on('log', log.info); // output build logs to terminal

a.on('update',bundle); // on any dep update, runs the bundler
a.on('log',bundle); // output build logs to terminal


function autoBundle() {
  return b
    .bundle()
    // log errors if they happen
    .on('error', log.error.bind(log, 'Browserify Error'))
    .on('end', () => {return console.timeEnd('Bundling finished')})
    .pipe(source('framework.js'))
    // optional, remove if you don't need to buffer file contents
    .pipe(buffer())
    // optional, remove if you dont want sourcemaps
    .pipe(sourcemaps.init({loadMaps: true})) // loads map from browserify file
    //.pipe(uglify())
    // Add transformation tasks to the pipeline here.
    .pipe(sourcemaps.write('../sourcemaps')) // writes .map file
    .pipe(gulp.dest('./packages'));
}

function bundle() {
  console.log('Bundling started...');
  console.time('Bundling finished');
  return a
    .bundle()
    // log errors if they happen
    .on('error', log.error.bind(log, 'Browserify Error'))
    .on('end', () => {console.timeEnd('Bundling finished')})
    .pipe(source('bundle.js'))
    // optional, remove if you don't need to buffer file contents
    .pipe(buffer())
    // optional, remove if you dont want sourcemaps
    .pipe(sourcemaps.init({loadMaps: true})) // loads map from browserify file
    //.pipe(uglify())
    // Add transformation tasks to the pipeline here.
    .pipe(sourcemaps.write('./', { addComment: false })) // writes .map file
    .pipe(gulp.dest('./packages'));
}