let config = {
    'authHistory': undefined,
    'authSession': undefined,
    'authHistoryView': undefined,
    'authSessionView': undefined,
    'participants': undefined,
    'participantsView': undefined,
    'participantsForm': undefined,
    'participantsFormView': undefined,
}

function authHistoryAPI() {
    fetch('../mock-data/Config.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let dataSource = data.dataSources;
            let view = data.views;
            config.authHistory = { ...dataSource.filter((item) => item.id == 'authHistory')[0]
            };
            config.authHistoryView = { ...view.filter((item) => item.id == 'authHistory')[0]
            };
            let authHContent = document.querySelector("#authHistory-content");
            let displayList = getTableContent(config.authHistory.mockDataSet,config.authHistoryView.columns);
            let displayHeader = getTableHeader(config.authHistoryView.columns);
            let markUp = `<table class="table table-bordered">
                    <thead>
                        <tr>${displayHeader}</tr>
                    </thead>
                    <tbody>${displayList}</tbody>
                </table>`
        
            if (authHContent) {
                authHContent.innerHTML = '<span style="display:none;"></span>';
                authHContent.innerHTML = config.authHistory && config.authHistoryView && markUp;
            }

        });
}


function authSessionAPI() {
    fetch('../mock-data/Config.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let dataSource = data.dataSources;
            let view = data.views;
            config.authSession = { ...dataSource.filter((item) => item.id == 'authSession')[0]
            };
            config.authSessionView = { ...view.filter((item) => item.id == 'authSession')[0]
            };
            let authSContent = document.querySelector("#authSession-content");
            let displayList = getTableContent(config.authSession.mockDataSet,config.authSessionView.columns);
            let displayHeader = getTableHeader(config.authSessionView.columns);
            let smarkUp = `<table class="table table-bordered">
                    <thead>
                        <tr>${displayHeader}</tr>
                    </thead>
                    <tbody>${displayList}</tbody>
                </table>
        `
            if (authSContent) {
                authSContent.innerHTML = '<span style="display:none;"></span>';
                authSContent.innerHTML = config.authSession && config.authSessionView && smarkUp;
            }
        });
}

function getTableHeader(columns) {
        return columns.map((column,columnIndex) => {
            return `<th>${column.label}</th>`
        }).join('');
}

function getTableContent(dataset,columns) {
    return dataset.map((record, recordIndex) => {
        let displayRows = getRowFields(record, columns);
        return `<tr>${displayRows}</tr>`
    }).join('');
}

function getRowFields(record,columns) {
    return columns.map((column, columnIndex) => {
        return `<td>${record[column.id]}</td>`;
    }).join('');
}



function participantsAPI() {
    fetch('../mock-data/Participants.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let dataSource = data.dataSources;
            let view = data.views;
            config.participants = { ...dataSource.filter((item) => item.id == 'participants')[0]
            };
            config.participantsView = { ...view.filter((item) => item.id == 'participants')[0]
            };
            let getDisplayer = (data, column) => {
                const _id = column.id;
                const dataType = typeof data[_id];
                switch (dataType) {
                    case 'string':
                    case 'number':
                    case 'boolean':
                        return data[_id];
                    case 'object':
                        let displayer = column.displayer.pattern.split('\n').map(d => d.slice(1, -1));
                        let seperator = column.displayer.separator + " ";
                        if (Array.isArray(data[_id])) {
                            let pArr = data[_id];
                            let homeChecked = column.homeChecked;
                            let obj;
                            if (homeChecked) {
                                obj = pArr.filter(a => a.context == 'home')[0];
                                if (!obj) {
                                    obj = pArr.filter(a => a.context == 'work')[0];
                                }
                            } else {
                                obj = pArr.filter(a => a.context == 'work')[0];
                                if (!obj) {
                                    obj = pArr.filter(a => a.context == 'home')[0];
                                }
                            }
                            // console.log('obj =>', obj, 'displayer =>', displayer);
                            displayer = displayer.map(i => obj[i]).filter(j => j).join(seperator);
                            return displayer;
                        } else {
                            let obj = data[_id];
                            displayer = displayer.map(i => obj[i]).filter(j => j).join(seperator);
                            return displayer;
                        }
                    default:
                        return data[_id];
                }
            }
            const newRecord = `
            <tr>
                    <td>
                        <div class="form-group row">
                        <label for="issuePartyId" class="col-sm-2 col-form-label">ISSUER PARTY ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="issuePartyId" name="issuePartyId" placeholder="ISSUER PARTY ID" />
                        </div>
                    </div>
                    </td>
                    
                     <td>
                        <div class="form-group row">
                            <label for="taxId" class="col-sm-2 col-form-label">TAXID</label>
                            <div class="col-sm-10">
                                <input type="text"  class="form-control-plaintext" id="taxId" name="taxId" placeholder="TAXID">
                            </div>
                        </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">EMPLOYMENT</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="EmployeeNumber">Employee Number</label>
                                <input type="text" class="form-control" id="EmployeeNumber" name="employeeNumber" placeholder="Employee Number">
                            </div>
                            <div class="form-group">
                                <label for="hiredate">Hire Date</label>
                                <input type="date" class="form-control" id="hiredate" name="hiredate" placeholder="Hire Date">
                            </div>
                            <div class="form-group">
                                <label for="terminatedate">Terminate Date</label>
                                <input type="date" class="form-control" name="terminate" id="terminatedate" placeholder="Hire Date">
                            </div>
                        </div>                        
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">FULL NAME</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="given">Given</label>
                                <input type="text" class="form-control" id="given" name="given" placeholder="Given">
                            </div>
                            <div class="form-group">
                                <label for="middle">Middle</label>
                                <input type="text" class="form-control" id="middle" name="middle" placeholder="Middle">
                            </div>
                            <div class="form-group">
                                <label for="family">Family</label>
                                <input type="text" class="form-control" id="family" name="family" placeholder="Family">
                            </div>
                        </div>                        
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">ADDRESSES</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="lineOne">Line One</label>
                                <input type="text" class="form-control" id="lineOne" name="lineOne" placeholder="Line One">
                            </div>
                            <div class="form-group">
                                <label for="lineTwo">Line Two</label>
                                <input type="text" class="form-control" id="lineTwo" name="lineTwo" placeholder="Line Two">
                            </div>
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" class="form-control" id="city" name="city" placeholder="City">
                            </div>
                             <div class="form-group">
                                <label for="countrySubdivision">Country Subdivision</label>
                                <input type="text" class="form-control" id="countrySubdivision" name="countrySubdivision" placeholder="Country Subdivision">
                            </div>
                             <div class="form-group">
                                <label for="postalCode">Postal Code</label>
                                <input type="text" class="form-control" id="postalCode" name="postalCode" placeholder="Postal Code">
                            </div>
                             <div class="form-group">
                                <label for="countryCode">Country Code</label>
                                <input type="text" class="form-control" id="countryCode" name="countryCode" placeholder="Country Code">
                            </div>
                        </div>                        
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">PHONE NUMBERS</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="digits">Digits</label>
                                <input type="text" class="form-control" id="digits" name="digits" placeholder="Digits">
                            </div>
                        </div>                        
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">EMAILADDRESSES</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                            </div>
                        </div>                        
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="id" class="col-sm-2 col-form-label">ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="id" name="id" placeholder="ID">
                        </div>
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="pormoted" class="col-sm-2 col-form-label">PROMOTED</label>
                        <div class="col-sm-10">
                             <input type="checkbox" class="form-check-input" id="pormoted" name="promoted" checked>
                        </div>
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="birthday" class="col-sm-2 col-form-label">BIRTHDAY</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="birthday" name="birthday"/>
                        </div>
                    </div>
                    </td>
                    <td>
                    <div class="form-group row">
                        <label for="uuid" class="col-sm-2 col-form-label">UUID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="uuid" name="uuid" placeholder="UUID">
                        </div>
                    </div>
                    </td>
                    <td>
                    <button type="button" id="updateBtn" class="btn btn-primary">Add New Record</button>
                    <button type="button" id="cancelBtn" class="btn btn-primary">CANCEL</button>
                    </td>
                </tr>`
                
            window.deleteRow = (i) => {
                config.participants.mockDataSet.splice(i, 1);
                participantsContent.innerHTML = pmarkUp();
            }

            window.updateRowRecord = () => {
                var elements = document.getElementById("updateUserForm").elements;
                var obj ={};
                for(var i = 0 ; i < elements.length ; i++){
                    var item = elements.item(i);
                    obj[item.name] = item.value;
                }

                config.participants.mockDataSet[window.updateRowIndex].addresses[0].city = obj.city;
                config.participants.mockDataSet[window.updateRowIndex].addresses[0].countryCode = obj.countryCode;
                config.participants.mockDataSet[window.updateRowIndex].addresses[0].countrySubdivision = obj.countrySubdivision;
                config.participants.mockDataSet[window.updateRowIndex].addresses[0].lineOne = obj.lineOne;
                config.participants.mockDataSet[window.updateRowIndex].addresses[0].lineTwo = obj.lineTwo;
                config.participants.mockDataSet[window.updateRowIndex].addresses[0].postalCode = obj.postalCode;
                config.participants.mockDataSet[window.updateRowIndex].birthDate = obj.birthDate;
                config.participants.mockDataSet[window.updateRowIndex].editable = obj.editable;
                config.participants.mockDataSet[window.updateRowIndex].emailAddresses[0].address = obj.address;
                config.participants.mockDataSet[window.updateRowIndex].employment.employeeNumber = obj.employeeNumber;
                config.participants.mockDataSet[window.updateRowIndex].employment.hireDate = obj.hireDate;
                config.participants.mockDataSet[window.updateRowIndex].employment.terminationDate = obj.terminationDate;
                config.participants.mockDataSet[window.updateRowIndex].fullName.family = obj.terminationDate;
                config.participants.mockDataSet[window.updateRowIndex].fullName.family = obj.terminationDate;
                config.participants.mockDataSet[window.updateRowIndex].fullName.family = obj.terminationDate;
                config.participants.mockDataSet[window.updateRowIndex].id = obj.id;
                config.participants.mockDataSet[window.updateRowIndex].issuerParty = obj.issuerParty;
                config.participants.mockDataSet[window.updateRowIndex].phoneNumbers[0].digits = obj.digits;
                config.participants.mockDataSet[window.updateRowIndex].promoted = obj.promoted;
                config.participants.mockDataSet[window.updateRowIndex].taxId = obj.taxId;
                config.participants.mockDataSet[window.updateRowIndex].uuid = obj.uuid;

                document.getElementById("pForm-table").deleteRow(window.updateRowIndex+1);
                participantsContent.innerHTML = pmarkUp();
            }

            window.updateRow = (i) => {
                window.updateRowIndex = i;
                var dataObj = config.participants.mockDataSet[i];
                console.log(dataObj)

            let  updateRowData = '<td><div class= form-group row > ' +
                 '<label for= issuePartyId  class= col-sm-2 col-form-label >ISSUER PARTY ID</label>' +
                 '<div class= col-sm-10 > ' +
                    '<input type= text  class= form-control  id= issuePartyId  name= issuePartyId  placeholder= ISSUER PARTY ID value=' +dataObj.issuerParty+'  />' +
                '</div> '+
                 '</div> </td>' +
                ' <td>' +
                        '<div class= form-group row >' +
                            '<label for= taxId  class= col-sm-2 col-form-label >TAXID</label>' +
                            '<div class= col-sm-10 >' +
                                '<input type= text   class= form-control-plaintext  id= taxId  name= taxId  placeholder= TAXID value='+dataObj.taxId+'> ' +
                            '</div>' +
                        '</div>' +
                    '</td>' +
                    '<td>' +
                   ' <div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >EMPLOYMENT</label>'+
                        '<div class= col-sm-10 >' +
                           ' <div class= form-group >' +
                                '<label for= EmployeeNumber >Employee Number</label>' +
                                '<input type= text  class= form-control  id= EmployeeNumber  name= employeeNumber  placeholder= Employee Number value='+dataObj.employment.employeeNumber+'>' +
                            '</div>' +
                            '<div class= form-group >' +
                                '<label for= hiredate >Hire Date</label>' +
                                '<input type= date  class= form-control  id= hiredate  name= hiredate  placeholder= Hire Date value='+dataObj.employment.hireDate+'>'+
                            '</div>'+
                            '<div class= form-group >' +
                                '<label for= terminatedate >Terminate Date</label>' +
                                '<input type= date  class= form-control  name= terminate  id= terminatedate  placeholder= Terminate Date value='+dataObj.employment.terminationDate+'>'+
                            '</div>' +
                        '</div>  '+                      
                   ' </div>' +
                   ' </td>'+
                    '<td>' +
                    '<div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >FULL NAME</label> ' +
                        '<div class= col-sm-10 >' +
                            '<div class= form-group >' +
                               ' <label for= given >Given</label>' +
                                '<input type= text  class= form-control  id= given  name= given  placeholder= Given value='+dataObj.fullName.given+'>'+
                            '</div>' +
                            '<div class= form-group >' +
                                '<label for= middle >Middle</label>'+
                                '<input type= text  class= form-control  id= middle  name= middle  placeholder= Middle value='+dataObj.fullName.middle+'>'+
                             '</div>' +
                            '<div class= form-group >' +
                               ' <label for= family >Family</label>'+
                                '<input type= text  class= form-control  id= family  name= family  placeholder= Family value='+dataObj.fullName.family+'>'+
                            '</div>'+
                        '</div>' +                 
                    '</div>' +
                    '</td>' +
                   ' <td>' +
                   ' <div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >ADDRESSES</label>' +
                       ' <div class= col-sm-10 >' +
                           ' <div class= form-group >' +
                                '<label for= lineOne >Line One</label>' +
                                '<input type= text  class= form-control  id= lineOne  name= lineOne  placeholder= Line One value='+dataObj.addresses[0].lineOne+'>' +
                            '</div>' +
                            '<div class= form-group >' +
                                '<label for= lineTwo >Line Two</label>' +
                                '<input type= text  class= form-control  id= lineTwo  name= lineTwo  placeholder= Line Two value='+dataObj.addresses[0].lineTwo+'>'+
                            '</div>'+
                            '<div class= form-group >'+
                                '<label for= city >City</label>' +
                                '<input type= text  class= form-control  id= city  name= city  placeholder= City value='+dataObj.addresses[0].city+'>'+
                            '</div>' +
                             '<div class= form-group >' +
                                '<label for= countrySubdivision >Country Subdivision</label>' +
                                '<input type= text  class= form-control  id= countrySubdivision  name= countrySubdivision  placeholder= Country Subdivision value='+dataObj.addresses[0].countrySubdivision+'>' +
                            '</div>' +
                             '<div class= form-group >' +
                                '<label for= postalCode >Postal Code</label>' +
                                '<input type= text  class= form-control  id= postalCode  name= postalCode  placeholder= Postal Code value='+dataObj.addresses[0].postalCode+'>'+
                            '</div>' +
                            '<div class= form-group >'+
                                '<label for= countryCode >Country Code</label>' +
                                '<input type= text  class= form-control  id= countryCode  name= countryCode  placeholder= Country Code value='+dataObj.addresses[0].countryCode+'>' +
                           ' </div>'+
                        '</div>  '+                      
                    '</div>'+
                   ' </td>' +
                   '<td>' +
                    '<div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >PHONE NUMBERS</label>' +
                       ' <div class= col-sm-10 >' +
                           ' <div class= form-group >' +
                                '<label for= digits >Digits</label>' +
                                '<input type= text  class= form-control  id= digits  name= digits  placeholder= Digits value='+dataObj.phoneNumbers[0].digits+'>' +
                            '</div>' +
                        '</div>        '+                
                    '</div>' +
                    '</td>'+
                    '<td>'+
                    '<div class= form-group row >'+
                        '<label for= taxId  class= col-sm-2 col-form-label >EMAILADDRESSES</label>' +
                        '<div class= col-sm-10 >' +
                            '<div class= form-group >' +
                                '<label for= address >Address</label>' +
                                '<input type= text  class= form-control  id= address  name= address  placeholder= Address value='+dataObj.emailAddresses[0].address+'>'+
                            '</div>' +
                        '</div>'+                        
                    '</div>' +
                    '</td>' +
                    '<td>' +
                    '<div class= form-group row >' +
                       ' <label for= id  class= col-sm-2 col-form-label >ID</label>' +
                         '<div class= col-sm-10 >' +
                            '<input type= text  class= form-control  id= id  name= id  placeholder= ID value='+dataObj.id+'>'+
                         '</div>' +
                    '</div>' +
                    '</td>' +
                    '<td>' +
                    '<div class= form-group row >'+
                        '<label for= pormoted  class= col-sm-2 col-form-label >PROMOTED</label>' +
                        '<div class= col-sm-10 >'+
                             '<input type= checkbox  class= form-check-input  id= pormoted  name= promoted  checked='+dataObj.promoted+'>' +
                        '</div>' +
                    '</div>' +
                    '</td>' +
                    '<td>' +
                   ' <div class= form-group row >' +
                        '<label for= birthday  class= col-sm-2 col-form-label >BIRTHDAY</label>' +
                        '<div class= col-sm-10 >' +
                            '<input type= date  class= form-control  id= birthday  name= birthday value='+dataObj.birthDate+'/>' +
                        '</div>' +
                    '</div>' +
                    '</td>' +
                    '<td>'+
                    '<div class= form-group row >'+
                        '<label for= uuid  class= col-sm-2 col-form-label >UUID</label>' +
                        '<div class= col-sm-10 >' +
                            '<input type= text  class= form-control  id= uuid  name= uuid  placeholder= UUID value='+dataObj.uuid+'>'+
                        '</div>' +
                    '</div>' +
                   ' </td>' +
                    '<td>' +
                    '<button type= button  id= updateBtn  class= btn btn-primary onclick=updateRowRecord()>Update Record</button>' +
                   ' </td>'
                    ;

                    document.getElementById("pForm-table").deleteRow(i+1);
                    var tableRef = document.getElementById("pForm-table");
                    var tr = tableRef.insertRow(i+1);
                    tr.innerHTML = updateRowData;
            }

            let participantsContent = document.querySelector("#participants-content");
            let pmarkUp = () => (`<form name=updateUserForm id=updateUserForm><table id='pForm-table'>
                    
                        <tr>
                            ${config.participantsView.columns.map((column) => `<th>${column.label}</th>`).join('')}
                            <th>ACTIONS</th>
                        </tr>
                                                                      
                        ${config.participants.mockDataSet.map((data, index) => `<tr>
                                ${
                                    config.participantsView.columns.map((column) => `<td>${getDisplayer(data, column)}</td>`).join('')
                                }
                                <td>
                                    <button type="button" onclick="updateRow(${index})">UPDATE</button>
                                    <button type="button" onclick="deleteRow(${index})">DELETE</button>
                                </td>
                            </tr>`).join('')} 
                                             
                        
                </table></form>
                <button type="button">CREATE A RECORD</button>
                <button type="button">SUBMIT</button>
        `);
            if (participantsContent) {
                participantsContent.innerHTML = '';
                participantsContent.innerHTML = config.participants && config.participantsView && pmarkUp();
            }
        });
}
 //adding new row to table
           function createRecord() {                    
                 var  newRecordData = '<td><div class= form-group row > ' +
                 '<label for= issuePartyId  class= col-sm-2 col-form-label >ISSUER PARTY ID</label>' +
                 '<div class= col-sm-10 > ' +
                    '<input type= text  class= form-control  id= issuePartyId  name= issuePartyId  placeholder= ISSUER PARTY ID  />' +
                '</div> '+
                 '</div> </td>' +
                ' <td>' +
                        '<div class= form-group row >' +
                            '<label for= taxId  class= col-sm-2 col-form-label >TAXID</label>' +
                            '<div class= col-sm-10 >' +
                                '<input type= text   class= form-control-plaintext  id= taxId  name= taxId  placeholder= TAXID > ' +
                            '</div>' +
                        '</div>' +
                    '</td>' +
                    '<td>' +
                   ' <div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >EMPLOYMENT</label>'+
                        '<div class= col-sm-10 >' +
                           ' <div class= form-group >' +
                                '<label for= EmployeeNumber >Employee Number</label>' +
                                '<input type= text  class= form-control  id= EmployeeNumber  name= employeeNumber  placeholder= Employee Number >' +
                            '</div>' +
                            '<div class= form-group >' +
                                '<label for= hiredate >Hire Date</label>' +
                                '<input type= date  class= form-control  id= hiredate  name= hiredate  placeholder= Hire Date >'+
                            '</div>'+
                            '<div class= form-group >' +
                                '<label for= terminatedate >Terminate Date</label>' +
                                '<input type= date  class= form-control  name= terminate  id= terminatedate  placeholder= Hire Date >'+
                            '</div>' +
                        '</div>  '+                      
                   ' </div>' +
                   ' </td>'+
                    '<td>' +
                    '<div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >FULL NAME</label> ' +
                        '<div class= col-sm-10 >' +
                            '<div class= form-group >' +
                               ' <label for= given >Given</label>' +
                                '<input type= text  class= form-control  id= given  name= given  placeholder= Given >'+
                            '</div>' +
                            '<div class= form-group >' +
                                '<label for= middle >Middle</label>'+
                                '<input type= text  class= form-control  id= middle  name= middle  placeholder= Middle >'+
                             '</div>' +
                            '<div class= form-group >' +
                               ' <label for= family >Family</label>'+
                                '<input type= text  class= form-control  id= family  name= family  placeholder= Family >'+
                            '</div>'+
                        '</div>' +                 
                    '</div>' +
                    '</td>' +
                   ' <td>' +
                   ' <div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >ADDRESSES</label>' +
                       ' <div class= col-sm-10 >' +
                           ' <div class= form-group >' +
                                '<label for= lineOne >Line One</label>' +
                                '<input type= text  class= form-control  id= lineOne  name= lineOne  placeholder= Line One >' +
                            '</div>' +
                            '<div class= form-group >' +
                                '<label for= lineTwo >Line Two</label>' +
                                '<input type= text  class= form-control  id= lineTwo  name= lineTwo  placeholder= Line Two >'+
                            '</div>'+
                            '<div class= form-group >'+
                                '<label for= city >City</label>' +
                                '<input type= text  class= form-control  id= city  name= city  placeholder= City >'+
                            '</div>' +
                             '<div class= form-group >' +
                                '<label for= countrySubdivision >Country Subdivision</label>' +
                                '<input type= text  class= form-control  id= countrySubdivision  name= countrySubdivision  placeholder= Country Subdivision >' +
                            '</div>' +
                             '<div class= form-group >' +
                                '<label for= postalCode >Postal Code</label>' +
                                '<input type= text  class= form-control  id= postalCode  name= postalCode  placeholder= Postal Code >'+
                            '</div>' +
                            '<div class= form-group >'+
                                '<label for= countryCode >Country Code</label>' +
                                '<input type= text  class= form-control  id= countryCode  name= countryCode  placeholder= Country Code >' +
                           ' </div>'+
                        '</div>  '+                      
                    '</div>'+
                   ' </td>' +
                   '<td>' +
                    '<div class= form-group row >' +
                        '<label for= taxId  class= col-sm-2 col-form-label >PHONE NUMBERS</label>' +
                       ' <div class= col-sm-10 >' +
                           ' <div class= form-group >' +
                                '<label for= digits >Digits</label>' +
                                '<input type= text  class= form-control  id= digits  name= digits  placeholder= Digits >' +
                            '</div>' +
                        '</div>        '+                
                    '</div>' +
                    '</td>'+
                    '<td>'+
                    '<div class= form-group row >'+
                        '<label for= taxId  class= col-sm-2 col-form-label >EMAILADDRESSES</label>' +
                        '<div class= col-sm-10 >' +
                            '<div class= form-group >' +
                                '<label for= address >Address</label>' +
                                '<input type= text  class= form-control  id= address  name= address  placeholder= Address >'+
                            '</div>' +
                        '</div>'+                        
                    '</div>' +
                    '</td>' +
                    '<td>' +
                    '<div class= form-group row >' +
                       ' <label for= id  class= col-sm-2 col-form-label >ID</label>' +
                         '<div class= col-sm-10 >' +
                            '<input type= text  class= form-control  id= id  name= id  placeholder= ID >'+
                         '</div>' +
                    '</div>' +
                    '</td>' +
                    '<td>' +
                    '<div class= form-group row >'+
                        '<label for= pormoted  class= col-sm-2 col-form-label >PROMOTED</label>' +
                        '<div class= col-sm-10 >'+
                             '<input type= checkbox  class= form-check-input  id= pormoted  name= promoted  checked>' +
                        '</div>' +
                    '</div>' +
                    '</td>' +
                    '<td>' +
                   ' <div class= form-group row >' +
                        '<label for= birthday  class= col-sm-2 col-form-label >BIRTHDAY</label>' +
                        '<div class= col-sm-10 >' +
                            '<input type= date  class= form-control  id= birthday  name= birthday />' +
                        '</div>' +
                    '</div>' +
                    '</td>' +
                    '<td>'+
                    '<div class= form-group row >'+
                        '<label for= uuid  class= col-sm-2 col-form-label >UUID</label>' +
                        '<div class= col-sm-10 >' +
                            '<input type= text  class= form-control  id= uuid  name= uuid  placeholder= UUID >'+
                        '</div>' +
                    '</div>' +
                   ' </td>' +
                    '<td>' +
                    '<button type= button  id= updateBtn  class= btn btn-primary >Add New Record</button>' +
                    '<button type= button  id= cancelBtn  class= btn btn-primary >CANCEL</button>'+
                   ' </td>'
                    ;

                    let tr = document.createElement('tr');
                    tr.innerHTML = newRecordData;
                    newTable.appendChild(tr);                   

                }

function participantsFormAPI() {
    fetch('../mock-data/Participants_form.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            let dataSource = data.dataSources;
            let view = data.views;
            config.participantsForm = { ...dataSource.filter((item) => item.id == 'participants')[0]
            };
            config.participantsFormView = { ...view.filter((item) => item.id == 'formParticipants')[0]
            };
            let isworkAviable = (items) => items.map(a => a.context).indexOf('work');
            let EmployeeFullName = (fullName) => fullName.given + ", " + fullName.middle + ", " + fullName.family;
            let adress = (addr) => {
                let ad = '';
                let isworkAvail = isworkAviable(addr)
                addr.forEach(a => {
                    ad = a.lineOne + ", " + a.lineTwo + ", " + a.city + ", " + a.countryCode + ", " + a.postalCode
                    if (isworkAvail > -1 && a.context == "work") {
                        return ad;
                    }
                })
                return ad;
            }
            let phoneNumber = (number) => {
                let num = '';
                let isworkAvail = isworkAviable(number)
                number.forEach(n => {
                    num = n.digits;
                    if (isworkAvail > -1 && n.context == "work") {
                        return num;
                    }
                })
                return num;
            };
            let emailAdress = (emails) => {
                let email = '';
                let isworkAvail = isworkAviable(emails)
                emails.forEach(e => {
                    email = e.address;
                    if (isworkAvail > -1 && e.context == "work") {
                        return email;
                    }
                })
                return email;
            }
            let getFormConten = (data, _id) => {
                if (typeof data[_id] === 'string' || typeof data[_id] === 'number' || typeof data[_id] === 'boolean') {
                    return data[_id];
                } else if (Array.isArray(data[_id])) {
                    if (_id === 'addresses') {
                        return adress(data[_id]) || '';
                    } else if (_id == "emailAddresses") {
                        return emailAdress(data[_id])
                    } else if (_id == "phoneNumbers") {
                        return phoneNumber(data[_id])
                    }
                } else if (typeof data[_id] === 'object') {
                    if (_id === 'fullName') {
                        return EmployeeFullName(data[_id]);
                    } else if (_id === 'employment') {
                        return data[_id].employeeNumber + ", " + data[_id].hireDate;
                    }
                }
            }

            function constructFormData(form, mockData) {
                /*address, birthday, city, countryCode, countrySubdivision, digits, employeenumber, family, given, hiredate, id, issuePartyId, lineOne, lineTwo, middle, postalCode, promoted, taxid, terminate, uuid */
                let data = formToJSON(form);
                const {
                    addresses,
                    birthDate,
                    emailAddresses,
                    employment,
                    fullName,
                    id,
                    issuerParty,
                    phoneNumbers,
                    promoted,
                    taxId,
                    uuid
                } = mockData;
                data = {
                    address: emailAdress(emailAddresses),
                    birthday: birthDate,
                    city: isworkAviable(addresses) ? addresses[1].city : addresses[0].city,
                    countryCode: isworkAviable(addresses) ? addresses[1].countryCode : addresses[0].countryCode,
                    countrySubdivision: isworkAviable(addresses) ? addresses[1].countrySubdivision : addresses[0].countrySubdivision,
                    digits: phoneNumber(phoneNumbers),
                    employeeNumber: employment.employeeNumber,
                    family: fullName.family,
                    given: fullName.given,
                    hiredate: employment.hireDate,
                    id,
                    issuePartyId: issuerParty,
                    lineOne: isworkAviable(addresses) ? addresses[1].lineOne : addresses[0].lineOne,
                    lineTwo: isworkAviable(addresses) ? addresses[1].lineTwo : addresses[0].lineTwo,
                    middle: fullName.middle,
                    postalCode: isworkAviable(addresses) ? addresses[1].postalCode : addresses[0].postalCode,
                    promoted: promoted ? "on" : "off",
                    taxId,
                    terminate: employment.terminationDate,
                    uuid,
                };
                // console.log(form, data);
                for (let d in data) {
                    if (data[d]) {
                        form[d].value = data[d];
                        // console.log(form[d], form[d].value,  data[d]);
                    }
                }

            }
            const formToJSON = elements => [].reduce.call(elements, (data, element) => {
                data[element.name] = element.value;
                return data;
            }, {});
            let participantsFormContent = document.querySelector("#participantsForm-content");
            let pfmarkUp = `<ul class="list-group">
                            ${config.participantsFormView.columns.map(p => (`<li class="list-group-item"><strong>${p.label}</strong> ${getFormConten(config.participantsForm.mockDataSet[0], p.id)}</li>`)).join('')}
                        </ul>
                        <button type="button" id="editBtn" class="btn btn-primary">EDIT</button>`
            const formMarkUp = `
            <form name="participantsForm">
                    <div class="form-group row">
                        <label for="issuePartyId" class="col-sm-2 col-form-label">ISSUER PARTY ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="issuePartyId" name="issuePartyId" placeholder="ISSUER PARTY ID" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">TAXID</label>
                        <div class="col-sm-10">
                            <input type="text" readonly class="form-control-plaintext" id="taxId" name="taxId" placeholder="TAXID">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">EMPLOYMENT</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="EmployeeNumber">Employee Number</label>
                                <input type="text" class="form-control" id="EmployeeNumber" name="employeeNumber" placeholder="Employee Number">
                            </div>
                            <div class="form-group">
                                <label for="hiredate">Hire Date</label>
                                <input type="date" class="form-control" id="hiredate" name="hiredate" placeholder="Hire Date">
                            </div>
                            <div class="form-group">
                                <label for="terminatedate">Terminate Date</label>
                                <input type="date" class="form-control" name="terminate" id="terminatedate" placeholder="Hire Date">
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">FULL NAME</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="given">Given</label>
                                <input type="text" class="form-control" id="given" name="given" placeholder="Given">
                            </div>
                            <div class="form-group">
                                <label for="middle">Middle</label>
                                <input type="text" class="form-control" id="middle" name="middle" placeholder="Middle">
                            </div>
                            <div class="form-group">
                                <label for="family">Family</label>
                                <input type="text" class="form-control" id="family" name="family" placeholder="Family">
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">ADDRESSES</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="lineOne">Line One</label>
                                <input type="text" class="form-control" id="lineOne" name="lineOne" placeholder="Line One">
                            </div>
                            <div class="form-group">
                                <label for="lineTwo">Line Two</label>
                                <input type="text" class="form-control" id="lineTwo" name="lineTwo" placeholder="Line Two">
                            </div>
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" class="form-control" id="city" name="city" placeholder="City">
                            </div>
                             <div class="form-group">
                                <label for="countrySubdivision">Country Subdivision</label>
                                <input type="text" class="form-control" id="countrySubdivision" name="countrySubdivision" placeholder="Country Subdivision">
                            </div>
                             <div class="form-group">
                                <label for="postalCode">Postal Code</label>
                                <input type="text" class="form-control" id="postalCode" name="postalCode" placeholder="Postal Code">
                            </div>
                             <div class="form-group">
                                <label for="countryCode">Country Code</label>
                                <input type="text" class="form-control" id="countryCode" name="countryCode" placeholder="Country Code">
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">PHONE NUMBERS</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="digits">Digits</label>
                                <input type="text" class="form-control" id="digits" name="digits" placeholder="Digits">
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label for="taxId" class="col-sm-2 col-form-label">EMAILADDRESSES</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" name="address" placeholder="Address">
                            </div>
                        </div>                        
                    </div>
                    <div class="form-group row">
                        <label for="id" class="col-sm-2 col-form-label">ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="id" name="id" placeholder="ID">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="pormoted" class="col-sm-2 col-form-label">PROMOTED</label>
                        <div class="col-sm-10">
                             <input type="checkbox" class="form-check-input" id="pormoted" name="promoted" checked>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="birthday" class="col-sm-2 col-form-label">BIRTHDAY</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="birthday" name="birthday"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="uuid" class="col-sm-2 col-form-label">UUID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="uuid" name="uuid" placeholder="UUID">
                        </div>
                    </div>
                    <button type="button" id="updateBtn" class="btn btn-primary">UPDATE</button>
                    <button type="button" id="cancelBtn" class="btn btn-primary">CANCEL</button>
                </form>`
            if (participantsFormContent) {
                participantsFormContent.innerHTML = '';
                participantsFormContent.innerHTML = config.participantsForm && config.participantsFormView && pfmarkUp;
            }

            const editBtn = document.querySelector("#editBtn");
            editBtn.addEventListener('click', editHandler);

            function editHandler() {
                if (participantsFormContent) {
                    participantsFormContent.innerHTML = '';
                    participantsFormContent.innerHTML = config.participantsForm && config.participantsFormView && formMarkUp;
                    constructFormData(document.forms.participantsForm, config.participantsForm.mockDataSet[0]);
                    const cancelBtn = document.querySelector('#cancelBtn');
                    cancelBtn.addEventListener('click', cancelHandler);
                    const updateBtn = document.querySelector("#updateBtn");
                    updateBtn.addEventListener('click', updateHandler);
                }
            };

            function cancelHandler() {
                if (participantsFormContent) {
                    // console.log(config.participantsForm.mockDataSet[0]);
                    pfmarkUp = ``;
                    pfmarkUp = `<ul class="list-group">
                            ${config.participantsFormView.columns.map(p => (`<li class="list-group-item"><strong>${p.label}</strong> ${getFormConten(config.participantsForm.mockDataSet[0], p.id)}</li>`)).join('')}
                        </ul>
                        <button type="button" id="editBtn" class="btn btn-primary">EDIT</button>`
                    participantsFormContent.innerHTML = '';
                    participantsFormContent.innerHTML = config.participantsForm && config.participantsFormView && pfmarkUp;
                    const editBtn = document.querySelector("#editBtn");
                    editBtn.addEventListener('click', editHandler);
                }
            };

            function updateHandler() {
                let data = formToJSON(document.forms.participantsForm);
                let formPostData = config.participantsForm.mockDataSet[0];
                addr = formPostData.addresses.filter(a => a.context === 'work')[0]
                addr.lineOne = data.lineOne
                addr.lineTwo = data.lineTwo
                addr.countryCode = data.countryCode
                addr.city = data.city
                addr.countrySubdivision = data.countrySubdivision
                addr.postalCode = data.postalCode
                formPostData.birthDate = data.birthday
                email = formPostData.emailAddresses[0]
                email.address = data.address
                formPostData.employment.employeeNumber = data.employeeNumber
                formPostData.employment.hireDate = data.hiredate
                formPostData.employment.terminationDate = data.terminate || null
                formPostData.fullName.family = data.family
                formPostData.fullName.given = data.given
                formPostData.fullName.middle = data.middle
                formPostData.issuerParty = data.issuePartyId
                phone = formPostData.phoneNumbers.filter(p => p.context === 'work')[0]
                phone.digits = data.digits
                formPostData.promoted = data.promoted === 'on' ? true : false
                formPostData.taxId = data.taxId
                formPostData.uuid = data.uuid
                formPostData.id = data.id
                cancelHandler()
            }
        });
}